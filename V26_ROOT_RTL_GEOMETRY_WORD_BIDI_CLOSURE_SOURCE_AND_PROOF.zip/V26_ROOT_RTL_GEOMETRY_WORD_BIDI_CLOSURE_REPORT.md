# V26 Root RTL Geometry + Word BiDi Closure

**Status: `PASS_READY_FOR_OWNER_VISUAL_SMOKE`**  
**Taste Pass:** not started or authorized.

## Root cause

V25 left the visible navigation to WPF `TabPanel`/`TabItem` header layout. The `FlowDirection` and content-alignment properties did not guarantee the required physical order. A horizontal `StackPanel` also kept child insertion order under RTL. V25's selected `TabItem` content was centered at its desired width, so the report composition occupied only about 479 DIP of a 1512 DIP content area; right-aligned text could not move that composition to the right edge.

The pre-fix WPF fixture reproduced this: Arabic report button x=1012, meeting-ask x=1182, vault-ask x=1352 inside a 500 DIP group—the group was right-anchored, but Report was physically leftmost. The report summary/card width was 479 DIP at x=508. V26 replaces the visible header strip with independent radio buttons, explicitly maps physical columns by language, and stretches selected tab content.

## Structural change

The visible `TabControl` headers were replaced with an explicit navigation `Grid` of three separately bordered, gap-separated, keyboard-accessible `RadioButton`s. The existing `TabControl` and its three content views remain as the single selection/content state. Arabic maps Report to the rightmost column; English uses the logical left-to-right order. The two-column report grid maps the first logical section to the right physical column in Arabic and left in English.

## Actual layout QA

`--rtl-layout-qa` instantiated and showed the WPF window at **1536×864 DIPs**, then read `ActualWidth/Height` and transformed rendered bounds relative to `ReportContentArea` (origin top-left). The full report area starts at x=12 in window content and is 1512 DIP wide (client-right edge x=1524). Coordinates below are relative to `ReportContentArea`.

| Language | Nav host (x, w, right) | Report button | Ask meeting | Ask vault |
|---|---:|---:|---:|---:|
| Arabic | 1012, 500, 1512 | 1352, 160, 1512 | 1182, 160, 1342 | 1012, 160, 1172 |
| English | 0, 500, 500 | 0, 160, 160 | 170, 160, 330 | 340, 160, 500 |

Each neighboring button has a measured 10 DIP gap; button rectangles are 160×42 DIP and do not overlap. The Arabic nav group's right edge equals the content area's right edge (1512/1512); the English group's left edge is x=0.

| Language | First paired card | Second paired card | Executive summary card | Summary text |
|---|---|---|---|---|
| Arabic | Topics: x=755.60, y=156.64, w=739.60, h=107.26, right=1495.20 | Key points: x=0, y=156.64, w=739.60, h=107.26, right=739.60 | x=0, y=60, w=1495.20, right=1495.20 | x=15, y=107.64, w=1465.20, right=1480.20 |
| English | Topics: x=0, y=156.64, w=739.60, h=107.26, right=739.60 | Key points: x=755.60, y=156.64, w=739.60, h=107.26, right=1495.20 | x=0, y=60, w=1495.20, right=1495.20 | x=15, y=107.64, w=1465.20, right=1480.20 |

Report cards are 739.60 DIP wide with a 16 DIP column gap and no overlap. The Arabic summary spans 1495.20 DIP to the right inset; its body text reaches the card's inner right edge. English positions mirror it. The serialized measurement evidence is `QA_EVIDENCE/RTL_LAYOUT_COORDINATES.json`.

## Word RTL QA

The self-test opened actual generated `.docx` packages as ZIPs and inspected `word/document.xml` and `word/styles.xml`; `OpenXmlValidator` returned zero errors for Arabic and English.

Arabic serialized proof:
- Section `w:bidi`: present.
- Arabic-containing paragraphs: 36; with paragraph `w:bidi`: 36.
- Normal `BodyText` paragraphs right-justified: 2/2.
- Arabic-containing runs: 40; with `w:rtl`: 40, language metadata `ar-SA`.
- Tables: 3; with `w:bidiVisual`: 3.
- `BodyText` style: `w:bidi` plus right justification.
- Latin `API` term remains logical and un-reversed in an LTR run.

English package retains LTR paragraph semantics and no RTL section/table layout. Machine evidence is in `QA_EVIDENCE/WORD_BIDI_SEMANTIC_PROOF.json`.

## Tests

- `dotnet build -c Release -r win-x64 --no-restore /nr:false` — PASS, 0 errors, 8 existing warnings.
- `dotnet publish -c Release -r win-x64 --no-restore -o src/PUBLISH /nr:false` — PASS.
- Published `src/PUBLISH/Archestro.MeetingVault.exe --rtl-layout-qa` — exit 0.
- Published EXE `--self-test` — exit 0; includes report language/title fixtures, serialized Arabic/English DOCX checks and `OpenXmlValidator`.
- Published EXE `--v13.8.9-qa` — exit 0.
- Published EXE `--v13.8-matrix` — exit 0.
- Published EXE `--ai-self-test` — exit 0 using the installed V25 Qwen model and llama runtime via process-only path overrides.
- Published EXE `--speaker-self-test` — exit 0 using installed V25 `SpeakerModels` via a process-only path override.
- The existing `--system-qa` was not run: its source hard-requires `faster-whisper`, while the actual installed setting is `native-whisper`; the task explicitly says not to change the user's transcription engine to satisfy an incompatible runner.
- V25 installed executable hash was verified as `76985810D7C9E8324BF0FCDC228277834CCEED7FC5674CEF3CB3042D9978EE81`. V26 did not modify the installed application. V26 AI/speaker QA invoked the exact published test binary with environment-only pointers to the installed runtime/model files.
- QA writes to the user's Logs directory were restored byte-for-byte to the pre-V26 snapshot: 47 files, zero hash differences. No app settings, meeting records, recordings, transcripts, models, or Aims data were modified.

## Feature preservation

XAML scan against the V25 source package: MainWindow relevant controls 75→75, event bindings 57→57; IntelligenceWindow relevant controls 28→31, event bindings 11→14. The three added controls replace visible tab headers; the original three tab content/state paths remain. Product actions removed: **0**. Home Recent files were not changed. Aims: **NO TOUCH**.

## Files changed

- `src/Archestro.MeetingVault/App.xaml.cs`
- `src/Archestro.MeetingVault/Dialogs/IntelligenceWindow.xaml`
- `src/Archestro.MeetingVault/Dialogs/IntelligenceWindow.xaml.cs`
- `src/Archestro.MeetingVault/Services/MeetingReportWordExporter.cs`
- `src/Archestro.MeetingVault/Services/SelfTestService.cs`

## Owner visual smoke checklist

1. Open the published V26 build and view an Arabic report: verify three separate controls ordered Report / Ask this meeting / Ask my vault from right to left; inspect full-width report cards and right-anchored headings/body.
2. Switch to English: verify the exact left-to-right mirror.
3. Export/open the Arabic DOCX in Word, click a normal Arabic body paragraph, and confirm Word indicates RTL paragraph direction; type Arabic, test Home/End, and confirm `API` remains readable.

## Next marker

`V26_READY_FOR_OWNER_VISUAL_SMOKE`

This is not owner visual acceptance and does not authorize Codex Taste Pass.