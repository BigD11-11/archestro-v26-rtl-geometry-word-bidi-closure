V26 RTL Geometry + Word BiDi Closure

Open V26_ROOT_RTL_GEOMETRY_WORD_BIDI_CLOSURE_REPORT.md for the verdict and owner smoke checklist.
source/ contains the exact changed source files.
QA_EVIDENCE/ contains actual WPF coordinate measurements, serialized DOCX semantic counts, test exits, and the published binary manifest.
The exact tested self-contained single-file executable is linked separately in the completion response; its SHA-256 is recorded in BUILD_PUBLISH_HASHES.txt.
The installed V25 application was not changed.